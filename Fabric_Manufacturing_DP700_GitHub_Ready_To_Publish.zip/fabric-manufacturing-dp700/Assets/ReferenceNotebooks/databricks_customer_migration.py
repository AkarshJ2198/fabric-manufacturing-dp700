# Databricks-style reference notebook: migrate this pattern to Fabric
# NOTE: This is a representative source artifact, not a runnable Databricks export.

dbutils.widgets.text("source_path", "/mnt/erp/customer")
dbutils.widgets.text("target_table", "silver.customer")
dbutils.widgets.text("batch_id", "BATCH_DEMO_001")

source_path = dbutils.widgets.get("source_path")
target_table = dbutils.widgets.get("target_table")
batch_id = dbutils.widgets.get("batch_id")

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from delta.tables import DeltaTable

df = spark.read.format("delta").load(source_path)
df = df.withColumn("BatchID", F.lit(batch_id))

w = Window.partitionBy("CustomerID").orderBy(F.col("ModifiedDate").desc())
df = df.withColumn("rn", F.row_number().over(w)).filter("rn = 1").drop("rn")

# Databricks-specific filesystem access to be replaced during migration:
# dbutils.fs.ls("/mnt/erp")

# Delta MERGE pattern (portable concept; validate runtime/table path in Fabric):
if spark.catalog.tableExists(target_table):
    target = DeltaTable.forName(spark, target_table)
    (target.alias("t")
        .merge(df.alias("s"), "t.CustomerID = s.CustomerID")
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute())
else:
    df.write.format("delta").saveAsTable(target_table)

print(f"Processed batch {batch_id}")
