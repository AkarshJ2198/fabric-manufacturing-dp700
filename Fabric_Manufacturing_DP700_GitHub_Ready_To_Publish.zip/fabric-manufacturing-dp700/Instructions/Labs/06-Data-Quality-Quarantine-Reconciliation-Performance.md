# Lab 06 – Data Quality, Quarantine, Reconciliation and Performance

## Objective
Implement reusable data quality controls and operational monitoring.

## Files required
- `Assets/Datasets/Customer_Exceptions.csv`
- `Assets/Datasets/Sales_Exceptions.csv`

## Step 1 – Load exception data
Upload the exception files to Bronze `Files/Exceptions` and read them into DataFrames.

## Step 2 – Define validation rules
Implement:
- CustomerID not null
- CustomerName not null
- Unique customer key
- SalesOrderID not null
- ProductID must exist
- Quantity greater than zero
- OrderDate not in the future

## Step 3 – Separate valid and invalid records
Create a validation result with:
- source record identifier
- batch ID
- rule name
- pass/fail status
- rejection reason
- validation timestamp

Write invalid records to `dq_quarantine` and valid records to the appropriate Silver table.

## Step 4 – Build reconciliation
Compare source, Bronze, valid Silver and quarantined counts. Verify:
`SourceCount = ValidCount + QuarantinedCount` for a batch where every record is classified exactly once.

Also compare sales amount and quantity aggregates.

## Step 5 – Build audit logging
Record:
- pipeline/run identifier
- table
- batch
- status
- source count
- inserted/updated/rejected count
- start and end timestamps
- error details

## Step 6 – Performance exercises
Use Spark explain plans and execution metrics to inspect:
- filter pushdown
- join strategy
- partition pruning
- data skew
- small-file behavior
- unnecessary shuffles

Discuss Delta compaction and capacity utilization; execute optimization commands only where supported by the lab runtime.

## Deliverables
- Reusable validation notebook
- `dq_validation_results`
- `dq_quarantine`
- `etl_reconciliation`
- `etl_audit_log`
- Performance observations

## Self-paced task
Add a new rule for valid supplier status and demonstrate that the framework can record the new rule without changing the overall processing pattern.
