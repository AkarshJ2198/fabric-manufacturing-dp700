# Lab 05 – Gold Layer, Warehouse and Power BI

## Objective
Build curated analytical datasets and validate reporting outputs.

## Prerequisites
Silver customer, product, sales, inventory and production tables from the supplied baseline or previous lab.

## Step 1 – Create dimensions
Create:
- `dim_customer`
- `dim_product`
- `dim_supplier`
- `dim_plant`

For the customer dimension, use only the current SCD2 row for current-state reporting, while retaining history for historical analysis.

## Step 2 – Create facts
Create:
- `fact_sales`
- `fact_inventory`
- `fact_production`

Validate business keys and join cardinality before writing.

## Step 3 – Create a sales summary
Build a Gold aggregation by region, product category, year and month. Calculate sales amount and quantity.

## Step 4 – Load or expose data in Warehouse
If Warehouse is available:
1. Create `WH_MFG_ANALYTICS`.
2. Create reporting schemas/tables or views.
3. Load curated Gold data using a supported Fabric approach.
4. Run SQL aggregations and compare them with Lakehouse results.

If Warehouse is not enabled, complete the analytical SQL exercise using the Lakehouse SQL analytics endpoint and document the limitation.

## Step 5 – Build Power BI report
Create visuals for:
- Total sales
- Sales by region
- Top products
- Inventory movements
- Production by plant
- Monthly sales trend

## Step 6 – Validate measures
Compare report totals with SQL queries against Gold tables.

## Deliverables
- Gold dimensions and facts
- Sales summary
- Warehouse SQL scripts or Lakehouse SQL evidence
- Power BI report and reconciliation evidence

## Self-paced task
Add a supplier performance KPI such as purchase/receipt volume by supplier, using only available source fields and clearly documenting any assumptions.
