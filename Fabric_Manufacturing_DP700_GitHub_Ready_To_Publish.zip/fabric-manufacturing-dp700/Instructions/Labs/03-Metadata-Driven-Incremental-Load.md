# Lab 03 – Metadata-Driven Incremental Ingestion

## Objective
Build a reusable ingestion pattern driven by configuration and watermark metadata.

## Files required
- `Assets/Metadata/etl_config.csv`
- `Assets/Metadata/etl_watermark.csv`
- `Assets/Datasets/Customer_Incremental.csv`
- `Assets/Datasets/SalesOrder_Incremental.json`

## Step 1 – Load metadata
1. Upload `etl_config.csv` and `etl_watermark.csv` to `LH_MFG_BRONZE/Files/Metadata`.
2. Read both files in a notebook.
3. Create Delta tables named `etl_config` and `etl_watermark`.

```python
config = (spark.read.option("header", True)
          .option("inferSchema", True)
          .csv("Files/Metadata/etl_config.csv"))
watermarks = (spark.read.option("header", True)
              .option("inferSchema", True)
              .csv("Files/Metadata/etl_watermark.csv"))
config.write.format("delta").mode("overwrite").saveAsTable("etl_config")
watermarks.write.format("delta").mode("overwrite").saveAsTable("etl_watermark")
```

## Step 2 – Upload incremental files
Upload `Customer_Incremental.csv` and `SalesOrder_Incremental.json` into `Files/Incremental`.

## Step 3 – Inspect the change feed
```python
inc = (spark.read.option("header", True)
       .option("inferSchema", True)
       .csv("Files/Incremental/Customer_Incremental.csv"))
display(inc)
```

## Step 4 – Apply a watermark filter
For the customer exercise, use `ModifiedDate` and the watermark value from `etl_watermark`. Convert date strings to dates before comparing.

## Step 5 – Implement idempotent processing
1. Deduplicate the incoming batch by business key and latest ModifiedDate.
2. MERGE into `brz_customer` or a designated staged target.
3. Ensure rerunning the same batch does not create duplicate business keys in the current-state target.
4. Record batch ID, start time, end time, row count and status in an audit table.
5. Update the watermark only after successful processing.

## Step 6 – Pipeline orchestration
Create a Fabric Data Factory pipeline with:
- Lookup for active metadata rows
- ForEach over configured tables
- Notebook activity for processing
- Success path for watermark update
- Failure path for audit and retry handling

Parameterize table name, source file, watermark column and batch ID.

## Deliverables
- `etl_config`
- `etl_watermark`
- `etl_audit_log`
- Incremental ingestion notebook
- Pipeline screenshot and run result

## Self-paced task
Add a new metadata row for a new source and demonstrate that the generic notebook can process it without changing its orchestration design.
