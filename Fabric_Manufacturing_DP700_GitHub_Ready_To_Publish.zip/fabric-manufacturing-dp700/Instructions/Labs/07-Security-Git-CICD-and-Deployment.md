# Lab 07 – Security, Governance, Git and Deployment

## Objective
Prepare the Fabric solution for controlled team development and deployment.

## Step 1 – Review workspace roles
Identify Admin, Member, Contributor and Viewer capabilities. Use only the permissions provided in the Skillable tenant.

## Step 2 – Review data access
Inspect Lakehouse and Warehouse permissions available in the environment. Discuss least privilege and separation of development and consumption access.

## Step 3 – Inspect lineage
Open lineage view for representative Lakehouse, notebook, pipeline and Power BI artifacts where supported. Record upstream and downstream dependencies.

## Step 4 – Connect Git
If enabled:
1. Open workspace settings.
2. Configure the approved Git provider and repository.
3. Select the intended branch and folder.
4. Commit supported Fabric artifacts.
5. Review changes and sync.
6. Resolve a simple change conflict if the tenant allows it.

If Git integration is unavailable, use the repository's local folder structure to practice source control concepts and submit exported notebook/SQL files.

## Step 5 – Deployment pipeline
If deployment pipelines are available and permitted:
1. Create Dev and Test workspaces or use trainer-provided workspaces.
2. Assign the workspaces to deployment stages.
3. Deploy supported artifacts.
4. Configure environment-specific connections and parameters.
5. Validate the deployed artifacts.

## Step 6 – Document controls
Create a deployment checklist covering approvals, validation, access, connections, rollback and monitoring.

## Deliverables
- Security and role matrix
- Lineage evidence
- Git commit evidence or exported source files
- Deployment checklist

## Self-paced task
Propose a production access model for data engineers, analysts and report consumers.
