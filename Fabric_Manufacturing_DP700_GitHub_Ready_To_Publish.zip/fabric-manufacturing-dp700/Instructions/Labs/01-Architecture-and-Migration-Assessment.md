# Lab 01 – Architecture Assessment and Migration Planning

## Objective
Assess a representative Databricks Medallion solution and design its Microsoft Fabric target architecture.

## Scenario
A manufacturing company consolidates customer, product, supplier, sales, inventory and production data. The current platform uses Databricks notebooks, Delta tables and scheduled jobs. The target platform is Microsoft Fabric.

## Step 1 – Review the source assets
1. Open the repository's `Assets/Datasets` folder.
2. Identify the customer, product, supplier, plant, sales order, sales detail, inventory and production files.
3. Open `Assets/ReferenceNotebooks/databricks_customer_migration.py`.
4. Identify Databricks-specific features such as `dbutils.widgets` and `dbutils.fs`.

## Step 2 – Create the Fabric workspace objects
1. Open your assigned Fabric workspace.
2. Create `LH_MFG_BRONZE`.
3. Create `LH_MFG_SILVER`.
4. Create `LH_MFG_GOLD`.
5. If available, create `WH_MFG_ANALYTICS`.

## Step 3 – Map source to target
Create a migration mapping table with these columns:
- Source component
- Current purpose
- Fabric target
- Migration action
- Validation approach
- Risk / dependency

Include at least:
- DBFS / cloud storage
- Delta tables
- PySpark notebooks
- Databricks Workflows
- Databricks SQL
- Unity Catalog governance concepts
- Power BI semantic models

## Step 4 – Draw the target architecture
Include:
1. Source systems (SQL Server ERP, CSV/JSON feeds and simulated API feed).
2. Fabric Data Factory.
3. Bronze, Silver and Gold Lakehouses.
4. Warehouse and Power BI.
5. Monitoring, security and Git/CI-CD.

## Step 5 – Validate the workspace
Confirm that all required Fabric items are visible and note any feature restrictions in the Skillable environment.

## Deliverables
- Target architecture diagram
- Databricks-to-Fabric mapping table
- Workspace and capacity readiness notes

## Self-paced task
Identify five migration risks and propose a mitigation for each.
