# Lab 08 – End-to-End Databricks-to-Fabric Migration Capstone

## Objective
Migrate a representative Databricks workload to Fabric, validate business outcomes and demonstrate failure recovery.

## Scenario
The manufacturing organization is moving its sales and inventory processing from Databricks to Fabric. Reporting continuity and data correctness are mandatory.

## Step 1 – Restore the capstone baseline
1. Create or open the assigned Fabric workspace.
2. Run the trainer-provided capstone setup notebook.
3. Restore source files and Bronze/Silver starter data.
4. Confirm baseline counts and schema.

## Step 2 – Migrate the reference notebook
1. Open `Assets/ReferenceNotebooks/databricks_customer_migration.py`.
2. Identify platform-specific dependencies.
3. Adapt parameters, paths, logging and Delta operations.
4. Execute the Fabric version.
5. Capture execution results and issues.

## Step 3 – Run equivalent input through both references
Use the supplied frozen Databricks expected-output dataset/reference results as the source-side comparison if no live Databricks workspace is provisioned.

## Step 4 – Reconcile
Compare:
- record counts
- business keys
- schema
- sales aggregates
- inventory aggregates
- current customer rows
- SCD2 history
- rejected records

Explain any intentional differences.

## Step 5 – Simulate a failed deployment
1. Introduce a controlled incorrect parameter or transformation.
2. Execute the affected pipeline/notebook.
3. Capture the failure.
4. Review audit and error logs.
5. Restore the known-good notebook/configuration from Git or the saved baseline.
6. Re-run validation.

## Step 6 – Define cutover
Document:
- entry criteria
- parallel-run duration
- reconciliation tolerances
- business approval
- reporting connection switch
- rollback trigger
- rollback owner
- post-cutover monitoring

## Step 7 – Present the solution
Each team demonstrates ingestion, transformation, quality controls, Gold reporting, monitoring and migration validation.

## Deliverables
- Working Fabric migration solution
- Reconciliation report
- Failure and recovery evidence
- Cutover and rollback checklist
- Short architecture walkthrough
