# Lab 04 – Delta MERGE, Deduplication, SCD and Schema Evolution

## Objective
Convert a representative Databricks PySpark transformation into a Fabric notebook and implement Delta processing patterns.

## Files required
- Bronze tables from Lab 02 baseline
- `Customer_Incremental.csv`
- `Product_Incremental.json`
- `Assets/ReferenceNotebooks/databricks_customer_migration.py`

## Step 1 – Review the Databricks notebook
Identify:
- `dbutils.widgets`
- `dbutils.fs`
- Spark DataFrame operations
- Delta MERGE
- Logging and error handling

Record which APIs are portable and which require adaptation.

## Step 2 – Replace parameters
Use Fabric notebook parameters or pipeline parameters for:
- source table/path
- target table
- batch ID

Do not assume a Databricks widget API exists unchanged in Fabric.

## Step 3 – Deduplicate
Use `row_number()` over the business key ordered by `ModifiedDate` descending. Retain the newest row per key.

## Step 4 – Implement Delta MERGE
Use `delta.tables.DeltaTable` and merge by the business key. Handle matched updates and unmatched inserts. Test a repeated batch to verify idempotency.

## Step 5 – Implement SCD Type 1
Use Product as the example:
1. Load product changes.
2. Match by ProductID.
3. Update changed attributes.
4. Insert new products.
5. Verify that only the latest product attributes remain in the current-state table.

## Step 6 – Implement SCD Type 2
Use Customer as the example. Add:
- `StartDate`
- `EndDate`
- `IsCurrent`
- `RecordHash`

When a tracked attribute changes:
1. Expire the previous current row.
2. Insert a new current row.
3. Preserve the old row for history.
4. Verify exactly one current record per CustomerID.

## Step 7 – Schema evolution
Read `Product_Incremental.json`, which includes `ProductSubCategory`.
Compare the incoming schema with the target schema. Decide whether to reject, add the column through a controlled schema change, or use supported Delta schema evolution. Validate the resulting schema.

## Deliverables
- Fabric-adapted notebook
- Deduplicated target
- SCD1 Product table
- SCD2 Customer table
- Schema evolution validation

## Self-paced task
Implement SCD Type 2 for Supplier and prove that historical rows remain queryable.
