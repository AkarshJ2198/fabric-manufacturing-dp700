# Lab 02 – Batch Ingestion and Bronze Layer

## Objective
Ingest manufacturing source files into OneLake and create raw Bronze Delta tables.

## Files required
From `Assets/Datasets`:
- `Customer.csv`
- `Product.csv`
- `Supplier.csv`
- `Plant.csv`
- `SalesOrder.csv`
- `SalesOrderDetail.csv`
- `InventoryMovement.csv`
- `Production.csv`

## Step 1 – Upload files
1. Open `LH_MFG_BRONZE`.
2. Select **Files**.
3. Create `SourceData`.
4. Upload the eight CSV files listed above.

## Step 2 – Create a notebook
1. Create a notebook named `NB_01_BRONZE_INGESTION`.
2. Attach `LH_MFG_BRONZE`.
3. Add a code cell and import:

```python
from pyspark.sql import functions as F
from datetime import datetime
import uuid
```

## Step 3 – Read a source file
```python
df = (
    spark.read
    .option("header", True)
    .option("inferSchema", True)
    .csv("Files/SourceData/Customer.csv")
)
display(df.limit(10))
```

## Step 4 – Add ingestion metadata
```python
batch_id = str(uuid.uuid4())

df_bronze = (
    df.withColumn("BatchID", F.lit(batch_id))
      .withColumn("IngestionTimestamp", F.current_timestamp())
      .withColumn("SourceSystem", F.lit("ERP"))
)
```

## Step 5 – Write the Bronze table
```python
(df_bronze.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("brz_customer"))
```

Repeat for the other seven source files, using table names:
- `brz_product`
- `brz_supplier`
- `brz_plant`
- `brz_salesorder`
- `brz_salesorderdetail`
- `brz_inventorymovement`
- `brz_production`

## Step 6 – Validate
```python
for table in [
    "brz_customer", "brz_product", "brz_supplier",
    "brz_plant", "brz_salesorder", "brz_salesorderdetail",
    "brz_inventorymovement", "brz_production"
]:
    print(table, spark.table(table).count())
```

## Expected baseline counts
- Customer: 500
- Product: 100
- Supplier: 60
- Plant: 4
- SalesOrder: 10,000
- InventoryMovement: 5,000
- Production: 2,500

SalesOrderDetail count varies with the generated file; use the actual source count as the baseline.

## Deliverables
- Eight Bronze Delta tables
- Notebook `NB_01_BRONZE_INGESTION`
- Count validation output

## Self-paced task
Ingest one additional copy of the Product file under a separate batch ID and explain why raw Bronze ingestion should preserve source history rather than silently overwrite it.
