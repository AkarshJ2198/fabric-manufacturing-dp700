# GitHub publishing guide

Target repository: `AkarshJ2198/fabric-manufacturing-dp700`
Visibility: Public

## Create the repository

1. Sign in to GitHub as `AkarshJ2198`.
2. Open https://github.com/new.
3. Set repository name to `fabric-manufacturing-dp700`.
4. Set visibility to **Public**.
5. Do not initialize with a README, `.gitignore` or license because this prepared folder already contains repository files.
6. Create the repository.

## Push this folder

From a terminal in this extracted folder, run:

```bash
git init
git branch -M main
git add .
git commit -m "Initial manufacturing DP-700 training labs"
git remote add origin https://github.com/AkarshJ2198/fabric-manufacturing-dp700.git
git push -u origin main
```

If Git reports that `origin` already exists, inspect it with `git remote -v` before changing it. Do not force-push over existing work.

## Verify after publishing

- Confirm the repository URL loads in a private/incognito browser window.
- Confirm the README and all eight lab guides render correctly.
- Open several dataset files and verify they download without authentication.
- Check that no credentials, tenant identifiers, production data or private client material were committed.
- Add a release/tag only after the labs have been validated in the target Skillable environment.

## Suggested repository settings

- Default branch: `main`.
- Add a repository description: `Hands-on Microsoft Fabric DP-700 manufacturing and supply-chain data engineering labs`.
- Topics: `microsoft-fabric`, `dp-700`, `data-engineering`, `manufacturing`, `supply-chain`, `databricks-migration`.
- Enable Issues only if you want participants to report lab issues publicly. Otherwise use the approved training support channel.
- Do not enable GitHub Pages; it is not required for this lab repository.
